package bmi;

public interface IFunk {
	double getBMI(String cpr);
	String getTextualBMI(String cpr);
	String getName(String cpr);
}
