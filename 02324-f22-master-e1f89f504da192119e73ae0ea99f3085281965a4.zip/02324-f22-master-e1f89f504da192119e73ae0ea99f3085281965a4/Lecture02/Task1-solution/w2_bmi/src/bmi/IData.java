package bmi;

public interface IData {
	String getName(String cpr);
	double getWeight(String cpr);
	double getHeight(String cpr);
}
