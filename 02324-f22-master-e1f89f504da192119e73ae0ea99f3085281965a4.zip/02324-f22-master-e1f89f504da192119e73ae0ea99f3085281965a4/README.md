# DTU 02324 Advance Programming course 
### Exercises for SPRING 2022   

This repository contains code from exercise sessions taking place in spring semester 2022. It includes both the code needed to start with particular exercise tasks and the code which represent the task solution.

For each lecture exercise there is a corresponding folder named LectureXX and within each such folder there are seperate subfolders containing the code for each exercise task . 

In RoboRally folder you can find versions of the RoboRally game app.